import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;

public class Hero extends GameObject {
	private boolean isDead, canSetMultiple;
	private int lives, xPos, yPos, speed;
	private Weapon weapon;
	private ArrayList<Weapon> multipleWeapons;
	private RangePowerUp rPowerUp;
	private ExplodePowerUp ePowerUp;
	private SpeedPowerUp mPowerUp;

	public Hero(int lives) {
		this.lives = lives;
		this.isDead = false;
		this.xPos = 50;
		this.yPos = 50;
		this.speed = 5;
		this.rPowerUp = null;
		this.ePowerUp = null;
		this.mPowerUp = null;
		this.multipleWeapons = new ArrayList<Weapon>();
		this.canSetMultiple = false;
		this.weapon = null;
	}

	@Override
	public void draw(Graphics2D g2) {
		String fileName = "BomberMan Sprites/Front Still.png";
		BufferedImage img;
		try {
			img = ImageIO.read(new File(fileName));
			g2.drawImage(img, null, (int) this.xPos, (int) this.yPos);
		} catch (IOException e) {
			
		}
		
		if (this.weapon != null) {
			this.weapon.draw(g2);
		}
	}

	public void setRPowerUp(RangePowerUp powerUp) {
		this.rPowerUp = powerUp;
	}
	
	public void setEPowerUp(ExplodePowerUp powerUp) {
		this.ePowerUp = powerUp;
	}
	
	public void setMPowerUp(SpeedPowerUp powerUp) {
		this.mPowerUp = powerUp;
	}
	
	public void setCanSetMultiple(boolean canSetMultiple) {
		this.canSetMultiple = canSetMultiple;
	}

	public void changeXBy(double x) {
		this.xPos += x;
	}

	public void setxPos(int xPos) {
		this.xPos = xPos;
		if(this.weapon != null){
			this.weapon.setPosition((int) this.xPos, (int) this.yPos);
		}
	}

	public void setyPos(int yPos) {
		this.yPos = yPos;
	}

	public void changeYBy(double y) {
		this.yPos += y;
	}

	@Override
	public double getxPos() {
		return this.xPos;
	}

	@Override
	public double getyPos() {
		return this.yPos;
	}

	public void useWeapon() {
		this.weapon = new Weapon();
		
		if(this.canSetMultiple) {
			this.multipleWeapons.add(this.weapon);
		}
		
		//range powerup handling
		if(this.rPowerUp != null) {
			this.weapon.setHasRangePower(true);
		}
		
		this.weapon.setPosition((int) this.xPos, (int) this.yPos);
	}

	public void update(BomberComponent bombComp) {
		if(this.ePowerUp == null) { 
			if (this.weapon != null) {
				if (this.weapon.getTime() > 4000) {
					this.weapon = null;
				} 
				else if (this.weapon.getTime() > 2000) {
					this.weapon.explode(bombComp);
				}
			}
		}
		else {
			if (this.weapon != null) {
				if (this.weapon.getTime() > 4000) {
					this.weapon = null;
				} 
			}
		}
	}

	public boolean getIsDead() {
		return this.isDead;
	}

	public int getLives() {
		return this.lives;
	}
	
	public void setLives(int lives) {
		this.lives = lives;
	}

	public void updateLives() {
		if (this.isDead == true) {
			this.lives -= 1;
			if (this.lives == 0) {
				// display game over message
			}
		}
		this.isDead = false;
	}

	public Weapon getWeapon() {
		return this.weapon;
	}

	public void setWeapon(Weapon weapon) {
		this.weapon = weapon;
	}

	public void setDead(boolean isDead) {
		this.isDead = isDead;
	}

	public void setSpeed(int factor) {
		this.speed = factor;
	}

	public double getSpeed() {
		return this.speed;
	}

	/**
	 * Param: i dependednt on direction checking for collision 1 is +y -1 is -y
	 * 2 is +x -2 is -x
	 */
	@Override
	boolean willCollide(BomberComponent bombComp, int i) { 
		// if trying +y i = 1, trying -y i = -1 trying +x i = 2, trying +y, trying -x i= -2
		Point2D objectPoint = new Point2D.Double(this.xPos + 15, this.yPos + 15);
		Point2D temp = new Point2D.Double(bombComp.getNearestObject(this).getxPos(),
				bombComp.getNearestObject(this).getyPos());
		double changeX, changeY;
		if (i == 1) {
			changeY = this.speed;
			changeX = 0;
		} else if (i == 2) {
			changeY = 0;
			changeX = this.speed;
		} else if (i == -1) {
			changeY = -this.speed;
			changeX = 0;
		} else {
			changeY = 0;
			changeX = -this.speed;
		}
		Point2D check = new Point2D.Double(this.xPos + 15 + changeX, this.yPos + 15 + changeY);
		if (objectPoint.distance(temp) < 35) {
			if (objectPoint.distance(temp) > check.distance(temp)) {
				return true;
			}
			return false;
		} else if (objectPoint.distance(temp) >= 35) {
			return false;
		}
		return false;
	}

	@Override
	void collide(GameObject m) {
		// this basically does nothing
		m.collideWithHero(this);

	}

	@Override
	void collideWithHero(Hero m) {
		// nothing, impossible

	}

	@Override
	void collideWithSquare(Square m) {
		// implement method to not allow collision

	}

	@Override
	void collideWithWeapon(Weapon m) {
		// same implementation as withSquare
	}

	@Override
	void collideWithMonster(Monster m) {
		this.setDead(true);
	}

	@Override
	void collideWithExplosion(WeaponExplosion m) {
		this.setDead(true);
	}

	@Override
	void collideWithRangePowerUp(RangePowerUp m) {
		this.rPowerUp = m;
		m.explode();
	}

	@Override
	void collideWithExplodePowerUp(ExplodePowerUp m) {
		this.ePowerUp = m;
		m.explode();
	}

	@Override
	void collideWithMultiplePowerUp(SpeedPowerUp m) {
		// TODO Auto-generated method stub.
	}

	@Override
	void collideWithGate(GateSquare m) {
		if(this.lives > 0) {
			if(m.getLevel().checkGateUnlocked()) {
				m.getLevel().setIsEntering(true);
			}
		}
	}
}
