import java.awt.Graphics2D;
import java.util.ArrayList;

public class Level extends GameObject{
	private Hero hero;
	private ArrayList<Monster> monsters;
	private ArrayList<StoneSquare> stoneSquares;
	private ArrayList<BrickSquare> brickSquares;
	private ArrayList<RangePowerUp> powerUp;
	private ArrayList<GateSquare> gateSquare;
	private boolean isEntering;

	
	@SuppressWarnings("unused")
	public Level() {
		this.hero = new Hero(3);
		this.monsters = new ArrayList<Monster>();
		this.stoneSquares = new ArrayList<StoneSquare>();
		this.brickSquares = new ArrayList<BrickSquare>();
		this.powerUp = new ArrayList<RangePowerUp>();
		this.gateSquare = new ArrayList<GateSquare>();
	}
	
	
	public ArrayList<StoneSquare> getStoneSquares() {
		return this.stoneSquares;
	}

	public ArrayList<BrickSquare> getBrickSquares() {
		return this.brickSquares;
	}
	
	public ArrayList<RangePowerUp> getPowerUp(){
		return this.powerUp;
	}
	
	public ArrayList<GateSquare> getGateSquare(){
		return this.gateSquare;
	}

	/**
	 * 
	 * Returns the Hero in this particular level.
	 *
	 * @return the Hero in this level.
	 */
	public Hero getHero() {
		return this.hero;
	}
	
	public ArrayList<Monster> getMonsters() {
		return this.monsters;
	}

	public boolean checkGateUnlocked() {
		if(this.hero.getLives() > 0) {
			for(Monster m : this.monsters) {
				if(m.isDead() == false) {
//					System.out.println("monster fault");
					return false;
				}
			}
			for(GateSquare s : this.getGateSquare()) {
				if(!s.isExploded()) {
					System.out.println("gate fault");
					return false;
				}
			}
		}
		return true;
	}


	public void update(BomberComponent bombComp) {
		for(Monster m : getMonsters()){
			m.update(bombComp);
		}
		this.hero.update(bombComp);
		if(getIsEntering() == true) {
			bombComp.increaseLevel();
			setIsEntering(false);
		}
	}

	public boolean getIsEntering() {
		return this.isEntering;
	}


	public void setIsEntering(boolean canEnter) {
		this.isEntering = canEnter;
	}


	public void draw(Graphics2D g2) {
		this.hero.draw(g2); //hero always starts in top left corner
		for(RangePowerUp p: this.powerUp){
			p.draw(g2);
		}
		for(GateSquare p: this.gateSquare) {
			p.draw(g2);
		}
	}


	@Override
	double getxPos() {
		// TODO Auto-generated method stub.
		return 0;
	}


	@Override
	double getyPos() {
		// TODO Auto-generated method stub.
		return 0;
	}


	@Override
	boolean willCollide(BomberComponent bombComp, int i) {
		// TODO Auto-generated method stub.
		return false;
	}


	@Override
	void collide(GameObject m) {
		// TODO Auto-generated method stub.
		
	}


	@Override
	void collideWithHero(Hero m) {
		// TODO Auto-generated method stub.
		
	}


	@Override
	void collideWithMonster(Monster monster) {
		// TODO Auto-generated method stub.
		
	}


	@Override
	void collideWithSquare(Square m) {
		// TODO Auto-generated method stub.
		
	}


	@Override
	void collideWithWeapon(Weapon m) {
		// TODO Auto-generated method stub.
		
	}


	@Override
	void collideWithExplosion(WeaponExplosion m) {
		// TODO Auto-generated method stub.
		
	}


	@Override
	void collideWithGate(GateSquare m) {
		// TODO Auto-generated method stub.
		
	}


	@Override
	void collideWithRangePowerUp(RangePowerUp m) {
		// TODO Auto-generated method stub.
		
	}


	@Override
	void collideWithExplodePowerUp(ExplodePowerUp m) {
		// TODO Auto-generated method stub.
		
	}


	@Override
	void collideWithMultiplePowerUp(SpeedPowerUp m) {
		// TODO Auto-generated method stub.
		
	}
}