import java.awt.Graphics2D;

public class BackgroundSquare extends Square {

	public BackgroundSquare(int xPos, int yPos) {
		this.canWalk = true;
		this.xPos = xPos;
		this.yPos = yPos;
	}
	
	@Override
	void explode() {
		//nothing to do on explosion
	}

	@Override
	public void draw(Graphics2D g2) {
		//nothing to do. Background square made as placeholder for Level creation.
	}
	
	@Override
	void collide(GameObject m) {
		//no collisions with Background Square	
	}
	
	@Override
	void collideWithHero(Hero m) {
		//nothing	
	}
	
	@Override
	void collideWithSquare(Square m) {
		//nothing	
	}
	
	@Override
	double getxPos() {
		return Double.MAX_VALUE; //so never selected as nearest object
	}
	
	@Override
	double getyPos() {
		return Double.MAX_VALUE; //so never selected as nearest object
	}
	
	@Override
	void collideWithMonster(Monster m) {
		//do nothing
	}
	
	@Override
	void collideWithExplosion(WeaponExplosion m) {
		// do Nothing	
	}
	
	@Override
	void collideWithRangePowerUp(RangePowerUp m) {
		// does not collide
		
	}
	
	@Override
	void collideWithExplodePowerUp(ExplodePowerUp m) {
		// does not collide	
	}
	
	@Override
	void collideWithMultiplePowerUp(SpeedPowerUp m) {
		// does not collide
	}
	
	@Override
	void collideWithGate(GateSquare m) {
		// does not collide	
	}
}
