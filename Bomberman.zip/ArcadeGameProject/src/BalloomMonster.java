import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

//I'd like to give credit to https://github.com/dtschust/javapacman/blob/master/Board.java
//Their code was helpful in making the Monster movement random

public class BalloomMonster extends Monster {
	
	public BalloomMonster(double xPos, double yPos) {
		//Buffalo Monster
		super(xPos, yPos);
		this.speed = 1.5;
	}
	
	@Override
	void draw(Graphics2D g2) {
		String fileName = "BomberMan Sprites/Garlic Monster.jpg";
		BufferedImage img;
		try {
			img = ImageIO.read(new File(fileName));
			g2.drawImage(img, null, (int) this.xPos, (int) this.yPos);
		} catch (IOException e) {
			
		}		
	}
	
	@Override
	void update(BomberComponent bombComp){
		if(this.isPaused == true) {
			stop();
		}
		else if(this.isPaused == false){
			//checks which direction is going to be traveled next
			checkDirection();
			if(canChooseDirection()) {
				setDirection(chooseNewDirection());
			}
			
			//handles collision with walls; in order: up, down, left, right
			if(willCollide(bombComp, 1) || willCollide(bombComp, -1) || 
					willCollide(bombComp, -2) || willCollide(bombComp, 2)) {
				if(bombComp.getNearestObject(this) == bombComp.getLevel().getHero()){
					this.collide(bombComp.getLevel().getHero());
				}
				this.bounce();
			}
		}
	}
	
	@Override
	boolean willCollide(BomberComponent bombComp, int i) {
		//i = 1 is UP, i = -1 is DOWN, i = 2 is RIGHT, i= -2 is LEFT
		Point2D objectPoint = new Point2D.Double(this.xPos + 10, this.yPos + 5);
		Point2D temp = new Point2D.Double(bombComp.getNearestObject(this).getxPos(), 
				bombComp.getNearestObject(this).getyPos());
		double changeX, changeY;
//		if(i == 1){
//			changeY = this.speed;
//			changeX = 0;
//		}
		if(i == 2){
			changeY = 0;
			changeX = this.speed;
		}
//		else if( i == -1){
//			changeY = -this.speed;
//			changeX = 0;
//		}
		else{
			changeY = 0;
			changeX = -this.speed;
		}
		Point2D check = new Point2D.Double(this.xPos + 15 + changeX, this.yPos + 15 + changeY);
		if(objectPoint.distance(temp) < 35){
			if(objectPoint.distance(temp) > check.distance(temp)){
				return true;
			}
				return false;
		}
		else if(objectPoint.distance(temp) >= 35){
			return false;
		}
		return false;
	}

	@Override
	void collideWithRangePowerUp(RangePowerUp m) {
		// nothing
	}

	@Override
	void collideWithExplodePowerUp(ExplodePowerUp m) {
		// nothing
	}

	@Override
	void collideWithMultiplePowerUp(SpeedPowerUp m) {
		// nothing
	}

	@Override
	void collideWithGate(GateSquare m) {
		// nothing
	}
}
