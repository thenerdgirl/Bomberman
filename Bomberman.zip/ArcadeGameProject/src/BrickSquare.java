import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class BrickSquare extends Square {

	public BrickSquare(int xPos, int yPos) {
		this.canWalk = true;
		this.xPos = xPos;
		this.yPos = yPos;
	}

	@Override
	void explode() {
		this.xPos = -50;
		this.yPos = -50;
	}

	@Override
	void draw(Graphics2D g2) {
		String fileName = "BomberMan Sprites/Brick Square.jpg";
		BufferedImage img;
		try {
			img = ImageIO.read(new File(fileName));
			g2.drawImage(img, null, (int) this.xPos, (int) this.yPos);
		} catch (IOException e) {
			
		}
	}

	@Override
	double getxPos() {
		return this.xPos + 20; //to get center x
	}
	@Override
	double getyPos() {
		return this.yPos + 20; //to get center y
	}

	@Override
	void collideWithMonster(Monster m) {
		//do nothing		
	}

	@Override
	void collideWithExplosion(WeaponExplosion m) {
		this.setOutput(20);
//		System.out.println(output);
//		System.out.println("brick explode ");
		this.explode();
	}

	@Override
	void collideWithRangePowerUp(RangePowerUp m) {
		// nothing
	}

	@Override
	void collideWithExplodePowerUp(ExplodePowerUp m) {
		// nothing
	}

	@Override
	void collideWithMultiplePowerUp(SpeedPowerUp m) {
		// nothing
	}

	@Override
	void collideWithGate(GateSquare m) {
		// nothing
	}
}