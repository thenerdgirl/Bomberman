import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyBoardListener implements KeyListener {
	private Hero hero;
	private BomberComponent b;
	private int numPClicked;
	
	public KeyBoardListener(Hero hero, BomberComponent b) {
		this.hero = hero;
		this.b = b;
		this.numPClicked = 0;
	}
	/**
	 * Handles key pressed events based on key codes.
	 * 
	 * Key:
	 * 37 - left arrow - moves hero in the negative x direction
	 * 38 - up arrow - moves hero in the positive y direction
	 * 39 - right arrow - moves hero in the positive x direction
	 * 40 - down arrow - moves hero in the negative y direction
	 * 
	 * 85 - 'U' - handles manually moving up a level
	 * 68 - 'D' - handles manually moving down a level
	 * 
	 * 80 - 'P' - handles pausing the game
	 * 
	 * 88 - 'X' - handles dropping a bomb in the hero's location
	 * 
	 * 32 - space bar - handles manually exploding a weapon when WeaponPowerUp is enabled
	 */
	@Override
	public void keyPressed(KeyEvent arg0) {
		
		if(arg0.getKeyCode() == 38) { // up arrow
			if(this.hero.getIsPaused() == true) {
				this.hero.changeYBy(0);
			}
			else {
				if(this.hero.willCollide(this.b, -1)){
					this.hero.collide(this.b.getNearestObject(this.hero));
				}
				else{
					this.hero.changeYBy(-this.hero.getSpeed());
				}
			}
		}
		else if(arg0.getKeyCode() == 40) { //down arrow
			if(this.hero.getIsPaused() == true) {
				this.hero.changeYBy(0);
			}
			else {
				if(this.hero.willCollide(this.b, 1)){
					this.hero.collide(this.b.getNearestObject(this.hero));
				}
				else{
					this.hero.changeYBy(this.hero.getSpeed());
				}
			}
		}
		else if(arg0.getKeyCode() == 37) {//left arrow
			if(this.hero.getIsPaused() == true) {
				this.hero.changeXBy(0);
			}
			else {
				if(this.hero.willCollide(this.b, -2)){
					this.hero.collide(this.b.getNearestObject(this.hero));
				}
				else{
					this.hero.changeXBy(-this.hero.getSpeed());
				}
			}
		}
		else if(arg0.getKeyCode() == 39) {//right arrow
			if(this.hero.getIsPaused() == true) {
				this.hero.changeXBy(0);
			}
			else {
				if(this.hero.willCollide(this.b, 2)){
					this.hero.collide(this.b.getNearestObject(this.hero));
				}
				else{
					this.hero.changeXBy(this.hero.getSpeed());
				}
			}
		}
		else if(arg0.getKeyCode() == 85) {//U - go up a level
			this.b.increaseLevel();
		}
		else if(arg0.getKeyCode() == 68) {//D - go down a level
			this.b.decreaseLevel();
		}
		else if(arg0.getKeyCode() == 88) {//x - drop a bomb
			this.hero.useWeapon();
			this.b.repaint();
			this.b.revalidate();
		}
		else if(arg0.getKeyCode() == 32) {//space bar - manual weapon exploding
			this.hero.getWeapon().explode(this.b);
			this.hero.update(this.b);
			this.b.repaint();
			this.b.revalidate();
		}
		else if(arg0.getKeyCode() == 80) { //P - pauses the game on even, unpauses on odd
			if(this.numPClicked == 0 || this.numPClicked % 2 == 0) {
				this.b.getLevel().getHero().setIsPaused(true);
				for (Monster m : this.b.getLevel().getMonsters()) {
					m.setIsPaused(true);
				}
			}
			else if (this.numPClicked % 2 != 0) {
				this.b.getLevel().getHero().setIsPaused(false);
				for (Monster m : this.b.getLevel().getMonsters()) {
					m.setIsPaused(false);
				}
			}
			this.numPClicked++;
		}
		//System.out.println(arg0.getKeyCode());
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		//nothing
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		//nothing
	}

}