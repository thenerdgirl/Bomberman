import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Weapon extends GameObject {
	protected double xPos, yPos;
	private double speed;
	private long time;
	private boolean hasExploded, hasRangePower;
	private WeaponExplosion explosion;

	public Weapon() {
		this.hasExploded = false;
		this.speed = 0;
		this.time = System.currentTimeMillis();
		this.explosion = new WeaponExplosion(this);
		this.hasRangePower = false;
	}

	@Override
	boolean willCollide(BomberComponent bombComp, int i) {
		return false;
	}

	@Override
	public double getxPos() {
		return this.xPos;
	}

	@Override
	public double getyPos() {
		return this.yPos;
	}

	public void setPosition(double x, double y) {
		this.xPos = x;
		this.yPos = y;
	}

	public boolean getExploded() {
		return this.hasExploded;
	}

	public void addTime() {
		this.time += .015;
	}

	public double getTime() {
		return System.currentTimeMillis() - this.time;
	}

	public void explode(BomberComponent bombComp) {
		this.hasExploded = true;
		this.explosion.setPosition((int)this.xPos, (int)this.yPos);
		this.explosion.update(bombComp);
	}

	@Override
	void draw(Graphics2D g2) {
		String fileName = "BomberMan Sprites/Bomb.png";
		BufferedImage img;
		try {
			img = ImageIO.read(new File(fileName));
			g2.drawImage(img, null, (int) this.xPos, (int) this.yPos);
		} catch (IOException e) {
			
		}
		if (this.hasExploded && this.hasRangePower == false) {
			this.explosion.draw(g2);
		}
		else if (this.hasExploded && this.hasRangePower == true) {
			this.explosion.drawPowered(g2);
		}
	}
	
	public void setHasRangePower(boolean hasRangePower) {
		this.hasRangePower = hasRangePower;
	}

	public WeaponExplosion getExplosion() {
		return this.explosion;
	}

	@Override
	void collide(GameObject m) {
		m.collideWithWeapon(this);

	}

	@Override
	void collideWithHero(Hero m) {
		// shouldnt allow collision

	}

	/**
	 * Handles a collision with a brick square, primarily.
	 */
	@Override
	void collideWithSquare(Square m) {
		//m.explode();
	}

	@Override
	void collideWithWeapon(Weapon m) {
		// nothing

	}

	@Override
	void collideWithMonster(Monster m) {
		// change for when the bomb explodes
		if (this.hasExploded == true) {
			m.die();
		}
	}

	@Override
	void collideWithExplosion(WeaponExplosion m) {
		// TODO set off other weapons
		
	}

	@Override
	void collideWithRangePowerUp(RangePowerUp m) {
		// nothing
	}

	@Override
	void collideWithExplodePowerUp(ExplodePowerUp m) {
		// nothing
	}

	@Override
	void collideWithMultiplePowerUp(SpeedPowerUp m) {
		// nothing
	}

	@Override
	void collideWithGate(GateSquare m) {
		// nothing
	}

}
