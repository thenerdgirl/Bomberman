
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;

public class CloseButtonListener implements ActionListener {
	private JFrame frame;

	/**
	 * 
	 * Constructs a CloseButtonListener object.
	 *
	 * @param frameToClose - the frame that will be exited out of.
	 */
	
	public CloseButtonListener(JFrame toClose) {
		this.frame = toClose;
	}

	/**
	 * 
	 * Closes the frame when the "Close" button is clicked.
	 * 
	 */
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		this.frame.dispose();
	}

}
