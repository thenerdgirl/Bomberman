import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class StoneSquare extends Square {
	
	public StoneSquare(int xPos, int yPos) {
		this.canWalk = false;
		this.xPos = xPos;
		this.yPos = yPos;
	}

	@Override
	void explode() {
		// does not explode
	}

	@Override
	public void draw(Graphics2D g2) {
		String fileName = "BomberMan Sprites/Stone Square.jpg";
		BufferedImage img;
		try {
			img = ImageIO.read(new File(fileName));
			g2.drawImage(img, null, (int) this.xPos, (int) this.yPos);
		} catch (IOException e) {
			
		}
		//g2.setColor(Color.WHITE);
		//g2.draw(stoneSquare);
	}
	
	@Override
	double getxPos() {
		return this.xPos + 20;//to get center x
	}
	@Override
	double getyPos() {
		return this.yPos + 20;//to get center y
	}

	@Override
	void collideWithMonster(Monster m) {
		//do nothing
	}

	@Override
	void collideWithExplosion(WeaponExplosion m) {
		// do Nothing
		
	}

	@Override
	void collideWithRangePowerUp(RangePowerUp m) {
		// TODO Auto-generated method stub.
		
	}

	@Override
	void collideWithExplodePowerUp(ExplodePowerUp m) {
		// TODO Auto-generated method stub.
		
	}

	@Override
	void collideWithMultiplePowerUp(SpeedPowerUp m) {
		// TODO Auto-generated method stub.
		
	}

	@Override
	void collideWithGate(GateSquare m) {
		// TODO Auto-generated method stub.
		
	}
	
}
