import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class ExplodePowerUp extends Square {
	private int xPos, yPos;
	private boolean exploded;
	
	public ExplodePowerUp(int xPos, int yPos) {
		this.xPos = xPos;
		this.yPos = yPos;
		this.exploded = false;
	}
	
	/**
	 * For PowerUp Squares, if an exlposion has not hit them yet, a brick square
	 * will be painted on the scene. Otherwise, the image depicting the PowerUp
	 * will be painted on the screen (after an explosion has hit it).
	 */
	
	@Override
	void draw(Graphics2D g2) {
		if(this.exploded == false){
			String fileName = "BomberMan Sprites/Brick Square.jpg";
			BufferedImage img;
			try {
				img = ImageIO.read(new File(fileName));
				g2.drawImage(img, null, (int) this.xPos, (int) this.yPos);
			} catch (IOException e) {
				
			}
		}
		if(this.exploded == true){
			String fileName = "BomberMan Sprites/PowerUp 2.jpg";
			BufferedImage img;
			try {
				img = ImageIO.read(new File(fileName));
				g2.drawImage(img, null, (int) this.xPos, (int) this.yPos);
			} catch (IOException e) {
				
			}
		}
		
	}

	@Override
	double getxPos() {
		return this.xPos + 20;
	}

	@Override
	double getyPos() {
		return this.yPos + 20;
	}

	@Override
	void collideWithHero(Hero m) {
		if(this.exploded == true) {
			this.explode();
			m.setEPowerUp(this);
		}		
	}

	@Override
	void collideWithMonster(Monster monster) {
		// nothing
	}

	@Override
	void collideWithSquare(Square m) {
		// nothing
	}

	@Override
	void collideWithWeapon(Weapon m) {
		// nothing
	}

	@Override
	void collideWithExplosion(WeaponExplosion m) {
		this.xPos = this.xPos;
		this.yPos = this.yPos;
		this.exploded = true;		
	}

	@Override
	void collideWithRangePowerUp(RangePowerUp m) {
		// nothing
	}

	@Override
	void collideWithExplodePowerUp(ExplodePowerUp m) {
		// nothing
	}

	@Override
	void explode() {
		this.xPos = -50;
		this.yPos = -50;
	}

	@Override
	void collideWithMultiplePowerUp(SpeedPowerUp m) {
		// nothing
	}

	@Override
	void collideWithGate(GateSquare m) {
		// nothing	
	}
}