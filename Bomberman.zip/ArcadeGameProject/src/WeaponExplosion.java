import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

public class WeaponExplosion extends GameObject {
	private Weapon weapon;
	private int xPos, yPos;
	private boolean explosionIsVisible;
	
	public WeaponExplosion(Weapon weapon) {
		this.weapon = weapon; 
		this.explosionIsVisible = false;
		this.xPos = -5000;
		this.yPos = -5000;
	}

	@Override
	void draw(Graphics2D g2) {
		g2.setColor(Color.RED);
		Rectangle2D.Double upAndDownExplode = new Rectangle2D.Double(this.xPos - 40, this.yPos, 120, 40);
		Rectangle2D.Double leftToRightExplode = new Rectangle2D.Double(this.xPos, this.yPos - 40, 40, 120);
		g2.fill(upAndDownExplode);
		g2.fill(leftToRightExplode);
	}
	
	void drawPowered(Graphics2D g2) {
		g2.setColor(Color.BLUE);
		Rectangle2D.Double upAndDownExplode = new Rectangle2D.Double(this.xPos - 100, this.yPos, 200, 40);
		Rectangle2D.Double leftToRightExplode = new Rectangle2D.Double(this.xPos, this.yPos - 100, 40, 200);
		g2.fill(upAndDownExplode);
		g2.fill(leftToRightExplode);
	}

	public void update(BomberComponent bombComp){
		int count = 0;
		for(GameObject[] g: bombComp.getFile().getBombBoard()){
			for(GameObject x: bombComp.getFile().getBombBoard()[count]){
				if(this.willCollide(bombComp, x)){
					this.collide(x);
				}
			}
			count++;
		}
		if(this.willCollide(bombComp, bombComp.getLevel().getHero())){
			this.collide(bombComp.getLevel().getHero());
			if(bombComp.getLevel().getHero().getIsDead()){
				bombComp.reloadLevel();
			}
		}
		
	}
	
	public boolean willCollide(BomberComponent bombComp, GameObject g){
		if(g.getxPos() <= this.xPos + 80 && g.getxPos() >= this.xPos - 40){			
			if(g.getyPos() <= this.yPos + 80 && g.getyPos() >= this.yPos - 40){
				return true;
			}
		}
		return false;
	}
	
	public boolean getIsVisible() {
		return this.explosionIsVisible;
	}

	public void setIsVisible(boolean isVisible) {
		this.explosionIsVisible = isVisible;
	}
	
	public void setPosition(int x, int y) {
		if(this.explosionIsVisible == false) {
			this.xPos = x;
			this.yPos = y;
		}
		else {
			this.xPos = -50;
			this.yPos = -50;
		}
	}
	
	public boolean willCollide(){
		return true;
	}
	
	@Override
	void collide(GameObject m) {
		m.collideWithExplosion(this);
	}

	@Override
	void collideWithHero(Hero m) {
		m.setDead(true);
	}

	@Override
	void collideWithMonster(Monster m) {
		m.die();
		//System.out.println("die monster");

	}

	@Override
	void collideWithSquare(Square m) {
		m.explode(); 
	}

	@Override
	void collideWithWeapon(Weapon m) {
		// TODO sets other weapons off
	}

	@Override
	boolean willCollide(BomberComponent bombComp, int i) {
		return false;
	}

	@Override
	void collideWithExplosion(WeaponExplosion m) {
		// do Nothing.
		
	}

	@Override
	void collideWithRangePowerUp(RangePowerUp m) {
//		if(this.hasPower == true) {
//			System.out.println("just collided with powerup");	
//			}				
	}

	@Override
	void collideWithExplodePowerUp(ExplodePowerUp m) {
		// nothing
	}

	@Override
	double getxPos() {
		return 0;
	}

	@Override
	double getyPos() {
		return 0;
	}

	@Override
	void collideWithMultiplePowerUp(SpeedPowerUp m) {
		//nothing
	}

	@Override
	void collideWithGate(GateSquare m) {
		//nothing
	}

}
