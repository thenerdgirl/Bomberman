import java.awt.BorderLayout;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;

/**
 * The main class for BomberMan.
 * 
 * @author Bradley Pender, Naomi Bhagat, Yuan (Olivia) Zhou
 *
 */

public class BomberMain {
	public static Hero hero;
	public Level level;
	private static final int WIDTH = 659;
	private static final int HEIGHT = 568;
	
	public static void main(String[] args) {
		

		//create the frame
		JFrame gameFrame = new JFrame();
		
		gameFrame.setSize(WIDTH, HEIGHT);
		gameFrame.setTitle("BomberMan!");
		
		final BomberComponent bombComp = new BomberComponent();
		gameFrame.add(bombComp);
		gameFrame.addKeyListener(new KeyBoardListener(bombComp.getLevel().getHero(), bombComp));
		
		gameFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		gameFrame.setVisible(true);
		
		// create the starting page
//		JFrame startFrame = new JFrame();
//		startFrame.setSize(WIDTH, HEIGHT);
//		startFrame.setTitle("BomberMan go!");
//						
//		JButton startButton = new JButton();
//		startButton.setText("Start game!!!");
//		ActionListener closeStartPage = new CloseButtonListener(startFrame);
//		startButton.addActionListener(closeStartPage);
//		startFrame.add(startButton, BorderLayout.SOUTH);
//		startFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//		startFrame.setVisible(true);
//		startFrame.pack();
		
		//create the key frame
		JFrame keyFrame = new JFrame();
		keyFrame.setSize(WIDTH, HEIGHT);
		keyFrame.setTitle("BomberMan!");
		
		JTextArea label = new JTextArea();
		label.setEditable(false);
		keyFrame.add(label, BorderLayout.CENTER);
		
		label.setText("  INSTRUCTIONS\n"
				+" \n"
				+" \n"
				+ "  You are the BomberMan! Drop bombs and blow up bricks and monsters to gain points. Some bricks contain\n"
				+ "  powerups that will help you achive you goals. After all the monsters are defeated, you must find the cave that \n"
				+ "  leads to the next level.\n"
				+" \n"
				+ "  You can die by colliding with a monster or getting caught in a bomb epxlosion. If you lose three lives, you will\n"
				+ "  have to start over. \n"
				+"  Happy Bombing! \n"
				+ " \n"
				+ " \n"
				+ "  KEY\n"
				+" \n"
				+ "  P: Pause the game. Click again to un-pause.\n"
				+" \n"
				+ "  Arrow Keys: Move the Hero\n"
				+" \n"
				+ "  X: Drop a bomb (will explode after 2 seconds).\n"
				+" \n"
				+ "  Grass Power Up: Extends the range of explosion.\n"
				+" \n"
				+ "  Sandwich Power Up: Manually explode bombs using the SPACE BAR.\n"
				+" \n"
				+ "  Wild Wings Power Up: Increase your speed.\n"
				+" \n"
				+"  U: load next level \n"
				+" \n"
				+"  D: load previous level \n");
				
		
		JButton closeButton = new JButton();
		closeButton.setText("Start this exciting game!!!!");
		ActionListener close = new CloseButtonListener(keyFrame);
		closeButton.addActionListener(close);
		keyFrame.add(closeButton, BorderLayout.SOUTH);
		
		keyFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		keyFrame.setVisible(true);
//		keyFrame.pack();
		
		//Start new thread for the game
		Runnable bomberRunnable = new Runnable() {

			@Override
			public void run() {
				while (true) {
					bombComp.getLevel().update(bombComp);
					if (bombComp.getLevel().getHero().getIsDead()) {
						bombComp.getLevel().getHero().updateLives();
						bombComp.getLevel().getHero().setDead(false);
						System.out.println(bombComp.getLevel().getHero().getLives() + " lives remaining");
						bombComp.reloadLevel();
					}
					bombComp.repaint();
					try {
						Thread.sleep(15);
					} catch (InterruptedException exception) {
						exception.printStackTrace();
					}
				}

			}
		};

		Thread t = new Thread(bomberRunnable);
		t.start();
	}
}
