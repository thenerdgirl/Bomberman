public abstract class Square extends GameObject {
	protected int xPos, yPos;
	protected boolean canWalk;
	
	public Square() {
		//empty constructor
	}
	
	@Override
	boolean willCollide(BomberComponent bombComp, int i){
		return false;
	}
	
	@Override
	void collide(GameObject m) {
		m.collideWithSquare(this);
	}
	
	@Override
	void collideWithHero(Hero m) {
//		System.out.println("just collided with square");
		//implement not allowing player to collide with square
		
	}
	@Override
	void collideWithSquare(Square m) {
		//nothing, impossible	
	}
	
	@Override
	void collideWithWeapon(Weapon m){
		//nothing, impossible
	}
	
	abstract void explode();
}
