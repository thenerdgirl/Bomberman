import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class RangePowerUp extends Square {
	//this power up is for distance of bomb explosion
	private int xPos, yPos;
	private boolean exploded;
	
	public RangePowerUp(int xPos, int yPos) {
		this.xPos = xPos;
		this.yPos = yPos;
		this.exploded = false;
	}

	@Override
	void explode() {
		this.xPos = -50;
		this.yPos = -50;
	}
	
	/**
	 * For PowerUp Squares, if an exlposion has not hit them yet, a brick square
	 * will be painted on the scene. Otherwise, the image depicting the PowerUp
	 * will be painted on the screen (after an explosion has hit it).
	 */
	
	@Override
	void draw(Graphics2D g2) {
		if(this.exploded == false){
			String fileName = "BomberMan Sprites/Brick Square.jpg";
			BufferedImage img;
			try {
				img = ImageIO.read(new File(fileName));
				g2.drawImage(img, null, (int) this.xPos, (int) this.yPos);
			} catch (IOException e) {
				
			}
		}
		if(this.exploded == true){
			String fileName = "BomberMan Sprites/PowerUp 1.jpg";
			BufferedImage img;
			try {
				img = ImageIO.read(new File(fileName));
				g2.drawImage(img, null, (int) this.xPos, (int) this.yPos);
			} catch (IOException e) {
				
			}
		}
		
	}

	@Override
	double getxPos() {
		return this.xPos + 20;//to get center x
	}

	@Override
	double getyPos() {
		return this.yPos + 20;//to get center y
	}

	@Override
	void collideWithMonster(Monster monster) {
		//nothing here
	}

	@Override
	void collideWithExplosion(WeaponExplosion m) {
		this.xPos = this.xPos;
		this.yPos = this.yPos;
		this.exploded = true;
	}
	
	@Override
	void collideWithHero(Hero m) {
		if(this.exploded == true) {
			this.explode();
			m.setRPowerUp(this);
		}
	}
	
	@Override
	void collideWithRangePowerUp(RangePowerUp m) {
		//nothing here
	}

	@Override
	void collideWithExplodePowerUp(ExplodePowerUp m) {
		// TODO Auto-generated method stub.
		
	}

	@Override
	void collideWithMultiplePowerUp(SpeedPowerUp m) {
		// TODO Auto-generated method stub.
		
	}

	@Override
	void collideWithGate(GateSquare m) {
		// TODO Auto-generated method stub.
		
	}

}
