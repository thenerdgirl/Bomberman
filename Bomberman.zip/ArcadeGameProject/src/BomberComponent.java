import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionListener;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;

public class BomberComponent extends JComponent {
	private Level level;
	private Color color = Color.green;
	private int levelNumber;
	FileReader file;
	
	public BomberComponent() {
		this.level = new Level();
		this.file = new FileReader(1, this.level);
		this.levelNumber = 1;
	}
	
	@Override
	protected void paintComponent (Graphics g) {
		super.paintComponent(g);
		
		//creates the initial green background
		Graphics2D g2 = (Graphics2D) g;
		Rectangle2D.Double background = new Rectangle2D.Double(0, 0, 800, 650);
		g2.setColor(this.color);
		g2.fill(background);
		
		//draw the hero in each scene
		this.level.draw(g2);
		
		//fills board with squares and game objects (excluding the hero)
		for (int r = 0; r < this.file.getBombBoard().length; r++) {
			for (int c = 0; c < this.file.getBombBoard()[r].length; c++) {
				this.file.getBombBoard()[r][c].draw(g2);
			}
		}
	}
	
	public FileReader getFile() {
		return this.file;
	}
	
	/**
	 * 
	 * Switches levels in the positive direction (1 -> 2, 2 -> 3).
	 *
	 */
	
	public void increaseLevel(){
		if(this.levelNumber == 4){
			JFrame keyFrame = new JFrame();
			keyFrame.setSize(659, 568);
			keyFrame.setTitle("BomberMan!");
			
			JButton died = new JButton();
			died.setText("You Won!!!!! Congrats!!!! :) \n" + "Your score is "  );
			keyFrame.add(died, BorderLayout.CENTER);
			
			
			
			JButton closeButton = new JButton();
			closeButton.setText("Start over!!!!");
			ActionListener close = new CloseButtonListener(keyFrame);
			closeButton.addActionListener(close);
			keyFrame.add(closeButton, BorderLayout.SOUTH);
			
			keyFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			keyFrame.setVisible(true);
			this.levelNumber = 1;
			this.file = new FileReader(this.levelNumber, this.level);
			this.level.getHero().setxPos(50);
			this.level.getHero().setyPos(50);
			this.level.getHero().setLives(3);
			this.level.getHero().setWeapon(null);
			this.level.getHero().setRPowerUp(null);
			this.level.getHero().setEPowerUp(null);
			this.level.getHero().setMPowerUp(null);			
		}
		else {
			for (int r = 0; r < this.file.getBombBoard().length; r++) {
				for (int c = 0; c < this.file.getBombBoard()[r].length; c++) {
					this.file.getBombBoard()[r][c] = null;
				}
			}
			for(Monster m : this.level.getMonsters()) {
				m.setIsDead(true);
				m.die();
			}
			this.file = new FileReader(this.levelNumber + 1, this.level);
			this.level.getHero().setxPos(50);
			this.level.getHero().setyPos(50);
			this.level.getHero().setWeapon(null);
			this.level.getHero().setRPowerUp(null);
			this.level.getHero().setEPowerUp(null);
			this.level.getHero().setMPowerUp(null);
			this.levelNumber++;
		}
	}
	
	/**
	 * 
	 * Switches levels in the positive direction once the gate has been
	 * unlocked and the Hero has collided with the gate to move on to the
	 * next level.
	 *
	 */
	
	public void completeLevel() {
		if(this.level.getIsEntering() == true && this.levelNumber != 3) {
			increaseLevel();
			for(GateSquare g : this.level.getGateSquare()) {
				g.explode();
			}
		}
//		if (this.level.getIsEntering() == true && this.levelNumber == 3) {
//			
//		}
	}
	
	/**
	 * 
	 * Switches levels in the negative direction (2 -> 1, 3 -> 2)
	 *
	 */
	
	public void decreaseLevel(){
		this.file = new FileReader(this.levelNumber - 1, this.level);
		this.level.getHero().setxPos(50);
		this.level.getHero().setyPos(50);
		this.level.getHero().setWeapon(null);
		this.level.getHero().setRPowerUp(null);
		this.level.getHero().setEPowerUp(null);
		this.level.getHero().setMPowerUp(null);
		this.levelNumber--;
	}
	
	/**
	 * 
	 * When the Hero dies, this method is called to reset the Level.
	 * When the Hero runs out of lives, his lives are reset, and he 
	 * must return to Level 1.
	 *
	 */
	
	public void reloadLevel(){
		if(this.level.getHero().getLives() != 0) {
			for(Monster m : this.level.getMonsters()) {
				m.setIsDead(true);
				m.die();
			}
			for(GateSquare g : this.level.getGateSquare()) {
				g.setExploded(true);
			}
			this.file = new FileReader(this.levelNumber, this.level);
			this.level.getHero().setxPos(50);
			this.level.getHero().setyPos(50);
			this.level.getHero().setWeapon(null);
			this.level.getHero().setRPowerUp(null);
			this.level.getHero().setEPowerUp(null);
			this.level.getHero().setMPowerUp(null);
		}
		else {
			JFrame keyFrame = new JFrame();
			keyFrame.setSize(659, 568);
			keyFrame.setTitle("BomberMan!");
			
			JButton died = new JButton();
			died.setText("You Died :(   " + "your score is " + this.level.getOutput() );
			keyFrame.add(died, BorderLayout.CENTER);
			
			JButton closeButton = new JButton();
			closeButton.setText("Start over!!!!");
			ActionListener close = new CloseButtonListener(keyFrame);
			closeButton.addActionListener(close);
			keyFrame.add(closeButton, BorderLayout.SOUTH);
			
			keyFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			keyFrame.setVisible(true);
			this.levelNumber = 1;
			this.file = new FileReader(this.levelNumber, this.level);
			this.level.getHero().setxPos(50);
			this.level.getHero().setyPos(50);
			this.level.getHero().setLives(3);
			this.level.getHero().setWeapon(null);
			this.level.getHero().setRPowerUp(null);
			this.level.getHero().setEPowerUp(null);
			this.level.getHero().setMPowerUp(null);
		}
	}
	
	
	/**
	 * 
	 * Gets the level currently being played when called.
	 *
	 * @return the current level.
	 */
	
	public Level getLevel() {
		return this.level;
	}
	
	/**
	 * 
	 * This method returns the nearest GameObject to the one in question. 
	 * Used primarily for the Hero's collisions, but also helps handle collisions
	 * between other game objects, such as a Monster and a Weapon.
	 *
	 *@param object: trying to find GameObject closest to object
	 *
	 * @return the closest GameObject.
	 */

	public GameObject getNearestObject(GameObject object){
		GameObject nearest = null;
		Point2D point = new Point2D.Double(object.getxPos() + 15, object.getyPos() + 15);
		double nearestDistance = Double.MAX_VALUE;
		for (int r = 0; r < this.file.getBombBoard().length; r++) {
			for (int c = 0; c < this.file.getBombBoard()[r].length; c++) {
				if(this.file == null)
					System.out.println("file null");
				else if (this.file.getBombBoard() == null)
					System.out.println("Board null");
				else if (this.file.getBombBoard()[r][c] == null)
					System.out.println("Position null: " + r + " " + c);
				if(this.file.getBombBoard()[r][c] != object){
					Point2D temp = new Point2D.Double(this.file.getBombBoard()[r][c].getxPos(),
							this.file.getBombBoard()[r][c].getyPos());
					double distance = point.distance(temp);
					if (distance < nearestDistance) {
						nearestDistance = distance;
						nearest = this.file.getBombBoard()[r][c];
					}
				}
			}
		}
		if(this.level.getHero() != object){
			Point2D temp = new Point2D.Double(this.level.getHero().getxPos(), this.level.getHero().getyPos());
			double distance = point.distance(temp);
			if (distance < nearestDistance) {
				nearestDistance = distance;
				nearest = this.level.getHero();
			}
		}
		return nearest;
	}

}
