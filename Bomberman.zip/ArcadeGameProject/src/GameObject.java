import java.awt.Graphics2D;

public abstract class GameObject {
	protected boolean isPaused = false;
	protected static int output;

	public GameObject() {
		/*This class is used to group all our game objects together (excluding the hero)
		in order to be able to create each new level by reading the Level files. The class
		ensures that each game object's collisions are handled.*/
	}
	public int getOutput(){
		return this.output;
	}
	
	public void setOutput(int add){
		this.output = this.output + add;
	}
	
	public boolean getIsPaused() {
		return this.isPaused;
	}
	
	public void setIsPaused(boolean isPaused) {
		this.isPaused = isPaused;
	}
	
	/**
	 * 
	 * Handles drawing each game object/character onto the Graphics2D object.
	 *
	 * @param g2: the Graphics2D slate that is being drawn on.
	 */
	
	abstract void draw(Graphics2D g2);
	
	/**
	 * 
	 * These methods return the x and y positions of the various game objects.
	 *
	 * @return x-coordinate or y-coordinate of game object in question.
	 */
	
	abstract double getxPos();
	abstract double getyPos();
	
	/**
	 * 
	 * Checks whether an object will collide with another one.
	 * Varies between objects based on size and movement type.
	 *
	 * @param bombComp: the BomberComponent that is being drawn on.
	 * @param i: an integer that represents in which direction we are checking for
	 * 	collision.
	 * @return true if the object will collide with something else
	 */
	
	abstract boolean willCollide(BomberComponent bombComp, int i);
	
	/**
	 * 
	 * Each collide method handles a collision with a different type of game object.
	 * collide: deals with generic collisions.
	 * collideWithHero: deals with collisions with a Hero.
	 * collideWithMonster: deals with collisions with a Monster.
	 * collideWithSquare: deals with collisions with the types of Squares.
	 * collideWithWeapon: deals with collisions with a Weapon.
	 * collideWithExplosion: deals with collisions with a Weapon's explosion.
	 * collideWithGate: deals with collisions with a Gate (to enter the next level).
	 * collideWithRangePowerUp, collideWithExplodePowerUp, and collideWithMultiplePowerUp
	 * 	all handle collisions with different types of PowerUps in the game. 
	 *
	 * @param m: the type of game object being collided with.
	 */
	
	abstract void collide(GameObject m);
	abstract void collideWithHero(Hero m);
	abstract void collideWithMonster(Monster monster);
	abstract void collideWithSquare(Square m);
	abstract void collideWithWeapon(Weapon m);
	abstract void collideWithExplosion(WeaponExplosion m);
	abstract void collideWithGate(GateSquare m);
	abstract void collideWithRangePowerUp(RangePowerUp m);
	abstract void collideWithExplodePowerUp(ExplodePowerUp m);
	abstract void collideWithMultiplePowerUp(SpeedPowerUp m);
}
