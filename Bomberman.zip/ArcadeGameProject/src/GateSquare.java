import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class GateSquare extends Square {
	private int xPos, yPos;
	private boolean exploded;
	private Level level;
	
	public GateSquare(int xPos, int yPos, Level level) {
		this.xPos = xPos;
		this.yPos = yPos;
		this.exploded = false;
		this.level = level;
	}

	@Override
	void explode() {
		this.xPos = -50;
		this.yPos = -50;
	}
	
	public Level getLevel() {
		return this.level;
	}

	public boolean isExploded() {
		return this.exploded;
	}
	
	public void setExploded(boolean isExploded) {
		this.exploded = isExploded;
	}
	
	@Override
	void draw(Graphics2D g2) {
		if(this.exploded == false){
			String fileName = "BomberMan Sprites/Brick Square.jpg";
			BufferedImage img;
			try {
				img = ImageIO.read(new File(fileName));
				g2.drawImage(img, null, (int) this.xPos, (int) this.yPos);
			} catch (IOException e) {
				
			}
		}
		if(this.exploded == true){
			String fileName = "BomberMan Sprites/Gate.jpg";
			BufferedImage img;
			try {
				img = ImageIO.read(new File(fileName));
				g2.drawImage(img, null, (int) this.xPos, (int) this.yPos);
			} catch (IOException e) {
				
			}
		}
	}

	@Override
	double getxPos() {
		return this.xPos + 20;//to get center x

	}

	@Override
	double getyPos() {
		return this.yPos + 20;//to get center y
	}

	@Override
	void collideWithMonster(Monster monster) {
		//nothing
	}
	
	@Override
	void collideWithHero(Hero m) {
		
		if(m.getLives() > 0) {
			if(this.getLevel().checkGateUnlocked() == true) {
//				System.out.println("here");
				this.getLevel().setIsEntering(true);
				if(this.exploded == true) {
					this.explode();
				}
			}
		}
	}
	
	@Override
	void collideWithExplosion(WeaponExplosion m) {
		this.xPos = this.xPos;
		this.yPos = this.yPos;
		this.exploded = true;
	}

	@Override
	void collideWithRangePowerUp(RangePowerUp m) {
		// nothing
	}

	@Override
	void collideWithExplodePowerUp(ExplodePowerUp m) {
		// nothing
	}

	@Override
	void collideWithMultiplePowerUp(SpeedPowerUp m) {
		// nothing
	}

	@Override
	void collideWithGate(GateSquare m) {
		//nothing		
	}
}
