import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class FileReader {

	GameObject[][] bombBoard = new GameObject[13][16];
	private String file;
	private Level level;

	public FileReader(int n, Level level) {
		try {
			this.file = readLevel(n);
		} catch (FileNotFoundException exception) {
			exception.printStackTrace();
		}
		this.level = level;
		this.bombBoard = GetBoard(this.file);
	}

	public GameObject[][] getBombBoard() {
		return this.bombBoard;
	}

	/**
	 * 
	 * Converts a text file in the form of a 2D-array to a long, single line,
	 * string of text.
	 *
	 * @param n:
	 *            the number level the player is on.
	 * @return a single line of string based on the level text file.
	 * @throws FileNotFoundException
	 */

	public String readLevel(int n) throws FileNotFoundException {
		File inputFile = new File("Levels/Level " + n);
		String s = "";
		Scanner input;
		input = new Scanner(inputFile);
		while (input.hasNextLine()) {
			s += input.nextLine();
		}
		input.close();
		return s;
	}

	/**
	 * 
	 * Reads the long string of text and based on which characters appear, a
	 * GameObject is placed in the correct position on the board, which is a 2D
	 * Array.
	 *
	 * @param file:
	 *            The single string of text.
	 * @return The final playable game board.
	 */

	public GameObject[][] GetBoard(String file) {
		int fileIndex = 0;
		char current = file.charAt(fileIndex);
		for (int r = 0; r < this.bombBoard.length; r++) {
			for (int c = 0; c < this.bombBoard[r].length; c++) {
				current = file.charAt(fileIndex);
				if (current == 'S') {
					StoneSquare temp = new StoneSquare(c * 40, r * 40);
					this.bombBoard[r][c] = temp;
					this.level.getStoneSquares().add(temp);
				}
				else if (current == 'x') {
					this.bombBoard[r][c] = new BackgroundSquare(c * 40, r * 40);
				} 
				else if (current == 'R') {
					RangePowerUp temp = new RangePowerUp(c * 40, r * 40);
					this.bombBoard[r][c] = temp;
				}
				else if (current == 'E') {
					ExplodePowerUp temp = new ExplodePowerUp(c * 40, r * 40);
					this.bombBoard[r][c] = temp;
				}
				else if (current == 'W') {
					SpeedPowerUp temp = new SpeedPowerUp(c * 40, r * 40);
					this.bombBoard[r][c] = temp;
				}
				else if (current == 'B') {
					BrickSquare temp = new BrickSquare(c * 40, r * 40);
					this.bombBoard[r][c] = temp;
					this.level.getBrickSquares().add(temp);
				}
				else if (current == 'M') {
					GarlicMonster temp = new GarlicMonster(c * 40, r * 40.5);
					this.bombBoard[r][c] = temp;
					this.level.getMonsters().add(temp);
				}
				else if (current == 'Z') {
					SuperMonster temp = new SuperMonster(c * 40, r * 40.5,this.level.getHero());
					this.bombBoard[r][c] = temp;
					this.level.getMonsters().add(temp);
				}
				else if (current == 'O') {
					BalloomMonster temp = new BalloomMonster(c * 40, r * 40.5);
					this.bombBoard[r][c] = temp;
					this.level.getMonsters().add(temp);
				}
				else if (current == 'G') {
					GateSquare temp = new GateSquare(c * 40, r * 40, this.level);
					this.bombBoard[r][c] = temp;
					this.level.getGateSquare().add(temp);
				}
				fileIndex++;
			}
		}
		return this.bombBoard;
	}

}
