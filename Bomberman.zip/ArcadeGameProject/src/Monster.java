
public abstract class Monster extends GameObject {
	protected double xPos, yPos, speed;
	protected int direction = 1;
	boolean isDead;
	
	public Monster(double xPos, double yPos) {
		this.xPos = xPos;
		this.yPos = yPos;
	}
	
	/**
	 * Returns the x-coordinate of the monster in question.
	 */
	
	@Override
	double getxPos() {
		return this.xPos;
	}
	
	/**
	 * Returns the y-coordinate of the monster in question. 
	 */
	
	@Override
	double getyPos() {
		return this.yPos;
	}
	
	/**
	 * 
	 * A method to determine whether or not the monster has been killed.
	 *
	 * @return
	 */
	
	public boolean isDead() {
		return this.isDead;
	}
	
	public void setIsDead(boolean isDead) {
		this.isDead = isDead;
	}
	
	/**
	 * 
	 * Sets the position of a monster to a new place on the game board.
	 *
	 * @param xPos: the x-position of the new location.
	 * @param yPos: the y-position of the new location.
	 */
	
	void setPosition(double xPos, double yPos) {
		this.xPos = xPos;
		this.yPos = yPos;
	}
	
	/**
	 * 
	 * Kills the monster by moving it far off-screen so it can never come
	 * back onto the game board. It is considered killed.
	 *
	 */
	
	void die() {
		this.setOutput(50);
//		System.out.println(output);
		setIsDead(true);
		this.setPosition(-500, -500);
		
	}
	
	@Override
	void collide(GameObject m) {
		m.collideWithMonster(this);
	}

	@Override
	void collideWithHero(Hero m) {
//		System.out.println("collided with monster");
		m.setDead(true);
		this.setOutput(-30);
	}

	@Override
	void collideWithWeapon(Weapon m) {
		// nothing
	}

	@Override
	void collideWithMonster(Monster m) {
		// nothing, they just keep going
	}

	@Override
	void collideWithSquare(Square m) {
		// nothing to do here		
	}

	@Override
	void collideWithExplosion(WeaponExplosion m) {
		die();
//		System.out.println(this.isDead);
	}
	
	void moveLeft() {
		this.xPos -= this.speed;
		this.yPos += 0;
	}
	
	void moveRight() {
		this.xPos += this.speed;
		this.yPos += 0;	
	}
	
	void moveUp() {
		this.xPos += 0;
		this.yPos -= this.speed;
	}
	
	void moveDown() {
		this.xPos += 0;
		this.yPos += this.speed;
	}
	
	void stop() {
		this.xPos += 0;
		this.yPos += 0;
	}
	
	/**
	 * 
	 * This method checks if it's time for the monster to choose a new direction.
	 *
	 * @return if the monster is at the edge of a square
	 */
	
	boolean canChooseDirection() {
		if(this.xPos % 40 < 2 && this.yPos % 40 < 2) {
			return true;
		}
		return false;
	}
	
	/**
	 * 
	 * Chooses a new integer for a new random direction for the monster.
	 *
	 * @return the new random integer
	 */
	
	public int chooseNewDirection() {
		int random = (int)(Math.random()*4) +1;
		return random;
	}
	
	/**
	 * 
	 * Maps the random number to a specific direction.
	 *
	 */
	
	void checkDirection() {
		if(this.direction == 1) {
			moveUp();
		}
		else if(this.direction == 2) {
			moveLeft();
		}
		else if(this.direction == 3) {
			moveDown();
		}
		else if(this.direction == 4) {
			moveRight();
		}
	}
	
	public void setDirection(int direction) {
		this.direction = direction;
	}
	
	/**
	  * 
	  * Causes the monster to "bounce" off a square.
	  *
	  */
	
	void bounce() {
		if(this.direction == 1)
			setDirection(3);
		else if(this.direction == 2)
			setDirection(4);
		else if(this.direction == 3)
			setDirection(2);
		else 
			setDirection(1);
	}
	
	/**
	 * 
	 * Updates each monster's movements.
	 *
	 * @param bombComp: the BomberComponent on which the monster repaints itself.
	 */
	
	abstract void update(BomberComponent bombComp);
	
//	void update(BomberComponent bombComp){
//		if(this.isPaused == true) {
//			stop();
//		}
//		else if(this.isPaused == false){
//			//checks which direction is going to be traveled next
//			checkDirection();
//			if(canChooseDirection()) {
//				setDirection(chooseNewDirection());
//			}
//			
//			//handles collision with walls; in order: up, down, left, right
//			if(willCollide(bombComp, 1) || willCollide(bombComp, -1) || 
//					willCollide(bombComp, -2) || willCollide(bombComp, 2)) {
//				if(bombComp.getNearestObject(this) == bombComp.getLevel().getHero()){
//					this.collide(bombComp.getLevel().getHero());
//				}
//				this.bounce();
//			}
//		}
//	}
}
